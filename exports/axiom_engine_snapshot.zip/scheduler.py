import logging
import os
import threading

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from ai.images import _ensure_character_portraits, _ensure_codex_images
from ai.narration import _generate_chronicle, _generate_narrative_synopsis, _generate_tick_voice
from ai.simulation import _call_claude, _call_openai
from aeloria_llm import resolve_aeloria_llm_provider
from axiom_clock import (
    get_clock_state,
    is_tick_due,
    mark_processing,
    mark_tick_completed,
    pause_clock,
    resume_clock,
)
from audio_pipeline import generate_weekly_story
from engine.tick import run_tick as _engine_run_tick
from notifier import send_tick_notification
from world_state.io import (
    WORLD_STATE_FILE,
    _apply_pending_lore_mechanical,
    _clear_pending_lore,
    _load_pending_lore,
    _load_world_state,
    _save_history,
    _save_world_state,
    rollback_last_save,
    safe_save_world,
)
from world_state.validate import _canonicalize_world_state, ensure_world_structure, is_valid_world

logger = logging.getLogger(__name__)

TEST_MODE = os.getenv("AXIOM_TEST_MODE", "0").strip().lower() in ("1", "true", "yes", "on")
_scheduler = BackgroundScheduler(timezone="UTC")
_lock = threading.Lock()


def _broadcast(payload: dict) -> None:
    try:
        import tick_bus

        tick_bus.notify_tick(payload)
    except Exception as bus_err:
        logger.warning("tick_bus notify failed: %s", bus_err)


def run_tick():
    """Scheduler-level tick: load, AI world update, Axiom Engine, save, narrate."""
    if not _lock.acquire(blocking=False):
        raise RuntimeError("Axiom tick already in progress")
    mark_processing(True)
    _broadcast({"type": "tick_started", "clock": get_clock_state()})
    try:
        logger.info("Running world tick...")
        try:
            prev_state = _load_world_state()
            if not isinstance(prev_state, dict):
                logger.warning(
                    "run_tick: world_state.json was not an object (%s); using empty state fallback",
                    type(prev_state).__name__,
                )
                prev_state = {}
            pending_lore = _load_pending_lore()
            pending_lore_snapshot = list(pending_lore) if pending_lore else []

            provider = resolve_aeloria_llm_provider()
            logger.info("Aeloria LLM provider: %s", provider)
            try:
                if provider == "openai":
                    new_state = _call_openai(prev_state, pending_lore)
                else:
                    new_state = _call_claude(prev_state, pending_lore)
            except Exception as llm_exc:
                fallback_tick = int((prev_state or {}).get("tick", 0)) + 1
                fallback_day = f"Day {fallback_tick}"
                logger.warning(
                    "LLM tick generation failed; using local fallback simulation: %s",
                    llm_exc,
                )
                new_state = dict(prev_state or {})
                faction_identities = new_state.get("faction_identities", {})
                if isinstance(faction_identities, dict):
                    involved = list(faction_identities.keys())[:6]
                elif isinstance(faction_identities, list):
                    involved = [
                        row.get("name")
                        for row in faction_identities
                        if isinstance(row, dict) and row.get("name")
                    ][:6]
                else:
                    involved = []
                new_state["tick"] = fallback_tick
                new_state["world_date"] = fallback_day
                new_state["primary_event"] = {
                    "name": "The Clock Moves Without Prophecy",
                    "summary": (
                        "A quiet day passes without fresh divine insight. Existing tensions "
                        "and political momentum continue shaping Aeloria."
                    ),
                    "severity": 1,
                    "stage": "ongoing",
                    "trend": "stable",
                    "involved": involved,
                }
                fallback_note = {
                    "region": "Aeloria",
                    "text": (
                        "The day advanced under local simulation while the prophecy engine was unavailable."
                    ),
                    "impact": "low",
                }
                raw_recent = new_state.get("recent_events", [])
                if isinstance(raw_recent, list):
                    existing_recent = [row for row in raw_recent if isinstance(row, dict)]
                else:
                    existing_recent = []
                new_state["recent_events"] = [fallback_note] + existing_recent[:11]

            new_state = _engine_run_tick(new_state, prev_world=prev_state)
            new_state = _canonicalize_world_state(prev_state, new_state)
            if os.getenv("PAUSE_IMAGE_GEN", "0").strip().lower() not in ("1", "true", "yes"):
                _ensure_character_portraits(new_state)
                _ensure_codex_images(new_state)
            new_state = _canonicalize_world_state(prev_state, new_state)
            _apply_pending_lore_mechanical(new_state, pending_lore)
            _save_world_state(new_state)
            _save_history(new_state)
            _clear_pending_lore()

            send_tick_notification(new_state)
            logger.info("Tick %s complete - %s", new_state["tick"], new_state.get("world_date"))

            clock = mark_tick_completed()
            _broadcast(
                {
                    "type": "tick_completed",
                    "tick": new_state.get("tick"),
                    "world_date": new_state.get("world_date"),
                    "clock": clock,
                }
            )
            _broadcast(
                {
                    "type": "tick",
                    "tick": new_state.get("tick"),
                    "world_date": new_state.get("world_date"),
                    "clock": clock,
                }
            )

            chronicle = _generate_chronicle(new_state)
            if chronicle:
                new_state["chronicle"] = chronicle
                new_state = _canonicalize_world_state(prev_state, new_state)
                _apply_pending_lore_mechanical(new_state, pending_lore_snapshot)
                _save_world_state(new_state)

            _generate_tick_voice(chronicle, new_state["tick"])
            _generate_narrative_synopsis(new_state)
            return new_state
        except Exception as exc:
            mark_processing(False, str(exc))
            _broadcast({"type": "tick_failed", "error": str(exc), "clock": get_clock_state()})
            logger.error("Tick failed: %s", exc, exc_info=True)
            raise
    finally:
        _lock.release()


def _run_clock_loop():
    clock = get_clock_state()
    _broadcast({"type": "clock", "clock": clock})
    if not is_tick_due():
        return
    try:
        run_tick()
    except RuntimeError as exc:
        logger.info("Clock tick skipped: %s", exc)
    except Exception as exc:
        logger.error("Clock tick failed: %s", exc, exc_info=True)


def _run_monday_story():
    logger.info("Generating Monday audio story...")
    try:
        state = _load_world_state()
        if state:
            path = generate_weekly_story(state)
            logger.info("Monday story saved to %s", path)
        else:
            logger.warning("No world state yet - skipping Monday story.")
    except Exception as exc:
        logger.error("Monday story failed: %s", exc, exc_info=True)


def start_scheduler():
    _scheduler.add_job(_run_clock_loop, IntervalTrigger(seconds=1), id="axiom_clock", replace_existing=True)
    _scheduler.add_job(
        _run_monday_story,
        CronTrigger(day_of_week="mon", hour=9, minute=0, timezone="UTC"),
        id="monday_story",
        replace_existing=True,
    )
    if _scheduler.get_job("simulation_tick"):
        _scheduler.remove_job("simulation_tick")
    if _scheduler.get_job("world_tick"):
        _scheduler.remove_job("world_tick")
    logger.info("Axiom grand-strategy clock enabled: speed controls drive run_tick().")
    if not TEST_MODE:
        _scheduler.start()
        logger.info("Scheduler started - Axiom clock heartbeat every 1s, story every Monday 9am UTC.")
    else:
        logger.info("TEST_MODE=True - scheduler disabled, no background ticks.")

    if not WORLD_STATE_FILE.exists():
        logger.info("No world state found - generating initial state...")
        try:
            run_tick()
        except Exception as exc:
            logger.error("Initial world generation failed: %s", exc, exc_info=True)


def stop_scheduler():
    if _scheduler.running:
        _scheduler.shutdown(wait=False)
        logger.info("Scheduler stopped.")


def pause_ticks() -> None:
    pause_clock()
    _broadcast({"type": "clock", "clock": get_clock_state()})
    logger.info("Axiom clock paused.")


def resume_ticks() -> None:
    resume_clock()
    _broadcast({"type": "clock", "clock": get_clock_state()})
    logger.info("Axiom clock resumed.")
