from economic_pressure_decisions import run_economic_pressure_decisions
from diplomatic_faction_decisions import run_diplomatic_faction_decisions
from engine._core import _process_rebellions
from intrigue_system import run_intrigue_system
from legitimacy_system import run_legitimacy_system
from military_faction_decisions import run_military_faction_decisions


def test_economic_pressure_decisions_record_causality():
    world = {
        "tick": 12,
        "faction_power_state": [
            {"faction": "Vilefin Corsairs", "militaryPower": 44},
            {"faction": "Twin Cities", "militaryPower": 50},
        ],
        "faction_economy": [
            {
                "faction": "Vilefin Corsairs",
                "resources": {"grain": {"consumption": 100}},
                "shortage_effects": {
                    "grain": {"severity": 0.8},
                    "iron": {"severity": 0.0},
                    "timber": {"severity": 0.0},
                    "gold": {"severity": 0.0},
                },
            }
        ],
        "tick_history": [{"tick": 12}],
    }

    run_economic_pressure_decisions(world)

    records = [
        c
        for c in world.get("causality_ledger", [])
        if c.get("source") == "economic_pressure_decisions"
    ]
    assert len(records) == 1
    assert records[0]["domain"] == "economy"
    assert records[0]["actor"] == "Vilefin Corsairs"
    assert records[0]["decision"] == "raid_for_provisions"
    assert records[0]["severity"] >= 8
    assert records[0]["belief"] == ""


def test_military_faction_decisions_record_causality():
    world = {
        "tick": 13,
        "faction_power_state": [
            {"faction": "Groth Clans", "militaryPower": 45},
            {"faction": "Gilgeth Clans", "militaryPower": 40},
        ],
        "relationships": [
            {
                "faction_a": "Groth Clans",
                "faction_b": "Gilgeth Clans",
                "type": "war",
            }
        ],
        "faction_armies": [
            {
                "faction": "Groth Clans",
                "manpower": 1000,
                "morale": 50,
                "discipline": 50,
                "supply_status": "cut",
                "supply_level": 10,
            },
            {
                "faction": "Gilgeth Clans",
                "manpower": 800,
                "morale": 50,
                "discipline": 50,
                "supply_status": "connected",
                "supply_level": 80,
            },
        ],
        "tick_history": [{"tick": 13}],
    }

    run_military_faction_decisions(world)

    records = [
        c
        for c in world.get("causality_ledger", [])
        if c.get("source") == "military_faction_decisions"
    ]
    groth_record = next(c for c in records if c.get("actor") == "Groth Clans")
    assert groth_record["domain"] == "military"
    assert groth_record["decision"] == "retreat_to_safety"
    assert groth_record["severity"] == 12
    assert "logistics_collapse" in groth_record["pressure"]


def test_rebellion_processing_records_public_causality():
    world = {
        "tick": 20,
        "faction_power_state": [
            {
                "faction": "Twin Cities",
                "militaryPower": 55,
                "economicPower": 55,
                "politicalInfluence": 55,
            }
        ],
        "locations": [
            {
                "name": "Lowmarket",
                "owner": "Twin Cities",
                "controller": "Rebels",
                "original_controller": "Twin Cities",
                "rebel_faction": "Rebels",
                "in_rebellion": True,
                "rebellion_tick_started": 10,
                "rebellion_intensity": 60,
                "control": 0,
                "stability": 12,
            }
        ],
    }

    _process_rebellions(world)

    records = [
        c
        for c in world.get("causality_ledger", [])
        if c.get("source") == "rebellion_processing"
    ]
    assert len(records) == 1
    assert records[0]["domain"] == "rebellion"
    assert records[0]["decision"] == "seize_control"
    assert "Lowmarket" in records[0]["outcome"]


def test_intrigue_resolution_records_private_causality():
    world = {
        "tick": 30,
        "faction_power_state": [
            {"faction": "Shadow Court"},
            {"faction": "Twin Cities"},
        ],
        "faction_intrigue": [
            {
                "faction": "Shadow Court",
                "intrigue_level": 60,
                "spy_networks": {
                    "Twin Cities": {"network_strength": 55, "exposure": 5}
                },
            },
            {
                "faction": "Twin Cities",
                "counter_intelligence": 35,
                "spy_networks": {},
            },
        ],
        "intrigue_pending": [
            {
                "id": "INT-test",
                "action": "information_gathering",
                "source_faction": "Shadow Court",
                "target_faction": "Twin Cities",
                "actor": "quiet agent",
                "intelligence": 70,
                "gold_paid": 20,
                "ticks_required": 1,
                "started_tick": 28,
            }
        ],
        "intrigue_config": {
            "max_new_starts_per_tick": 0,
            "start_new_probability": 0,
        },
        "tick_history": [{"tick": 30}],
    }

    run_intrigue_system(world)

    records = [
        c
        for c in world.get("causality_ledger", [])
        if c.get("source") == "intrigue_system"
    ]
    assert len(records) == 1
    assert records[0]["domain"] == "intrigue"
    assert records[0]["actor"] == "Shadow Court"
    assert records[0]["decision"] == "information_gathering"
    assert "Twin Cities" in records[0]["affected"]


def test_diplomatic_decisions_record_causality():
    world = {
        "tick": 40,
        "faction_power_state": [
            {"faction": "Twin Cities", "militaryPower": 45},
            {"faction": "Tidefall", "militaryPower": 50},
        ],
        "ruler_legitimacy_scores": {"Twin Cities": 25},
        "relationships": [
            {
                "faction_a": "Twin Cities",
                "faction_b": "Tidefall",
                "type": "neutral",
                "trust": 82,
            }
        ],
        "locations": [
            {"name": "Twin Gates", "controller": "Twin Cities", "stability": 32}
        ],
        "tick_history": [{"tick": 40}],
    }

    run_diplomatic_faction_decisions(world)

    records = [
        c
        for c in world.get("causality_ledger", [])
        if c.get("source") == "diplomatic_faction_decisions"
    ]
    twin_record = next(c for c in records if c.get("actor") == "Twin Cities")
    assert twin_record["domain"] == "diplomacy"
    assert twin_record["decision"] == "marriage_diplomacy"
    assert "Tidefall" in twin_record["affected"]
    assert "legitimacy=25.0" in twin_record["pressure"]


def test_legitimacy_crisis_records_causality(monkeypatch):
    monkeypatch.setattr("legitimacy_system.random.random", lambda: 0.0)
    world = {
        "tick": 41,
        "leadership_state": [
            {
                "faction": "Fallen Crown",
                "dynasties": [{"status": "active", "prestige": 0}],
            }
        ],
        "dynastic_legitimacy": {"Fallen Crown": 0},
        "ruler_legitimacy_scores": {"Fallen Crown": 0},
        "faction_power_state": [
            {
                "faction": "Fallen Crown",
                "militaryPower": 0,
                "economicPower": 0,
                "politicalInfluence": 0,
            }
        ],
        "faction_economy": [
            {
                "faction": "Fallen Crown",
                "shortage_effects": {
                    "grain": {"severity": 1.0},
                    "gold": {"severity": 1.0},
                    "iron": {"severity": 1.0},
                    "timber": {"severity": 1.0},
                },
            }
        ],
        "locations": [
            {"name": "Broken Keep", "controller": "Fallen Crown", "stability": 0}
        ],
        "diplomatic_standing": {"Fallen Crown": 0},
        "world_treaty_order": 0,
        "tributary_resentment": {"Fallen Crown": 100},
        "population_state": [{"faction": "Fallen Crown", "pressure": 100}],
        "tick_history": [{"tick": 41}],
    }

    run_legitimacy_system(world)

    records = [
        c
        for c in world.get("causality_ledger", [])
        if c.get("source") == "legitimacy_system"
    ]
    assert len(records) == 1
    assert records[0]["domain"] == "legitimacy"
    assert records[0]["decision"] == "military_overthrow"
    assert records[0]["actor"] == "Fallen Crown"
    assert "legitimacy crisis" in records[0]["pressure"]
